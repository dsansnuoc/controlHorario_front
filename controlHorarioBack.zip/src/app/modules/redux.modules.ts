import { NgModule } from '@angular/core';
//import { EffectsArray } from '../app.effects';
//import { appReducers } from '../app.reducer';

@NgModule({
  declarations: [],
  imports: [
    //  StoreModule.forRoot(appReducers),
    //  EffectsModule.forRoot(EffectsArray),
  ],
  providers: [],
  exports: [],
  bootstrap: [],
})
export class ReduxModule {}
