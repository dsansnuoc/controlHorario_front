import { LoginEffects } from './effects/login.effects';

export const EffectsArray: any[] = [LoginEffects];
