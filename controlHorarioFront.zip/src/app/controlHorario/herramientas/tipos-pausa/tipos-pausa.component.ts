import { Component } from '@angular/core';

@Component({
  selector: 'app-tipos-pausa',
  standalone: true,
  imports: [],
  templateUrl: './tipos-pausa.component.html',
  styleUrl: './tipos-pausa.component.scss'
})
export class TiposPausaComponent {

}
