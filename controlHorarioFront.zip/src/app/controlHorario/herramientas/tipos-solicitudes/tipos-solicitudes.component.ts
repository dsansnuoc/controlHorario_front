import { Component } from '@angular/core';

@Component({
  selector: 'app-tipos-solicitudes',
  standalone: true,
  imports: [],
  templateUrl: './tipos-solicitudes.component.html',
  styleUrl: './tipos-solicitudes.component.scss'
})
export class TiposSolicitudesComponent {

}
