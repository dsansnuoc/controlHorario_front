import { Component } from '@angular/core';

@Component({
  selector: 'app-organizaciones',
  standalone: true,
  imports: [],
  templateUrl: './organizaciones.component.html',
  styleUrl: './organizaciones.component.scss'
})
export class OrganizacionesComponent {

}
